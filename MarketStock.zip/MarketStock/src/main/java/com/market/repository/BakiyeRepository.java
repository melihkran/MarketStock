package com.market.repository;

import com.market.model.Bakiye;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Repository
public class BakiyeRepository {
    private final JdbcTemplate jdbcTemplate;
    private final ExecutorService executorService;

    @Autowired
    public BakiyeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.executorService = Executors.newFixedThreadPool(1); // Bakiye için tek thread yeterli
    }

    public void save(Bakiye bakiye) {
        String sql = "INSERT INTO bakiye(id, miktar) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET miktar=?";
        CompletableFuture.runAsync(() -> {
            try {
                jdbcTemplate.update(sql,
                        bakiye.getId(),
                        bakiye.getMiktar(),
                        bakiye.getMiktar()); // ON CONFLICT için miktar parametresi
            } catch (Exception e) {
                System.err.println("Bakiye kaydedilirken hata: " + e.getMessage());
            }
        }, executorService);
    }

    public Optional<Bakiye> get() {
        String sql = "SELECT * FROM bakiye WHERE id = 1"; // Varsayılan olarak 1 ID'li bakiyeyi al
        try {
            Bakiye bakiye = jdbcTemplate.queryForObject(sql, this::mapRow);
            return Optional.ofNullable(bakiye);
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            return Optional.empty();
        } catch (Exception e) {
            System.err.println("Bakiye okunurken hata: " + e.getMessage());
            return Optional.empty();
        }
    }

    public void resetBakiye() {
        save(new Bakiye(1L, 0.0)); // Bakiyeyi sıfırla
    }

    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, java.util.concurrent.TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private Bakiye mapRow(ResultSet rs, int rowNum) throws SQLException {
        Bakiye bakiye = new Bakiye();
        bakiye.setId(rs.getLong("id"));
        bakiye.setMiktar(rs.getDouble("miktar"));
        return bakiye;
    }
} 