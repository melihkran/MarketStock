package com.market.repository;

import com.market.model.SatisKaydi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Collections;

@Repository
public class SatisKaydiRepository {
    private final JdbcTemplate jdbcTemplate;
    private final ExecutorService executorService;

    @Autowired
    public SatisKaydiRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.executorService = Executors.newFixedThreadPool(4); // 4 thread'lik bir thread pool
    }

    public void save(SatisKaydi satisKaydi) {
        String sql = "INSERT INTO satis_gecmisi(urunAdi, urunId, satisFiyati) VALUES(?,?,?)";
        CompletableFuture.runAsync(() -> {
            try {
                jdbcTemplate.update(sql,
                        satisKaydi.getUrunAdi(),
                        satisKaydi.getUrunId(),
                        satisKaydi.getSatisFiyati());
            } catch (Exception e) {
                System.err.println("Satış kaydı eklenirken hata: " + e.getMessage());
            }
        }, executorService);
    }

    public List<SatisKaydi> findAll() {
        String sql = "SELECT * FROM satis_gecmisi";
        CompletableFuture<List<SatisKaydi>> future = CompletableFuture.supplyAsync(() -> {
            try {
                return jdbcTemplate.query(sql, this::mapRow);
            } catch (Exception e) {
                System.err.println("Satış geçmişi listelenirken hata: " + e.getMessage());
                return Collections.emptyList();
            }
        }, executorService);

        try {
            return future.get();
        } catch (Exception e) {
            System.err.println("Satış geçmişi listelenirken hata: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    public void deleteAll() {
        String sql = "DELETE FROM satis_gecmisi";
        CompletableFuture.runAsync(() -> {
            try {
                jdbcTemplate.update(sql);
            } catch (Exception e) {
                System.err.println("Satış geçmişi temizlenirken hata: " + e.getMessage());
            }
        }, executorService);
    }

    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, java.util.concurrent.TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private SatisKaydi mapRow(ResultSet rs, int rowNum) throws SQLException {
        SatisKaydi satisKaydi = new SatisKaydi();
        satisKaydi.setId(rs.getLong("id"));
        satisKaydi.setUrunAdi(rs.getString("urunAdi"));
        satisKaydi.setUrunId(rs.getLong("urunId"));
        satisKaydi.setSatisFiyati(rs.getDouble("satisFiyati"));
        return satisKaydi;
    }
} 