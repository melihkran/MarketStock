package com.market.repository;

import com.market.model.Urun;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Repository
public class UrunRepository implements GenericRepository<Urun, Long> {
    private final JdbcTemplate jdbcTemplate;
    private final ExecutorService executorService;

    @Autowired
    public UrunRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.executorService = Executors.newFixedThreadPool(4); // 4 thread'lik bir thread pool
    }

    @Override
    public Urun save(Urun urun) {
        String sql = "INSERT INTO urunler(ad, barkod, fiyat, stokMiktari, kategori, sonGuncellemeTarihi, tedarikci) VALUES(?,?,?,?,?,?,?)";
        CompletableFuture.runAsync(() -> {
            try {
                jdbcTemplate.update(sql,
                        urun.getAd(),
                        urun.getBarkod(),
                        urun.getFiyat(),
                        urun.getStokMiktari(),
                        urun.getKategori(),
                        urun.getSonGuncellemeTarihi().toInstant(ZoneOffset.UTC).toEpochMilli(),
                        urun.getTedarikci());
            } catch (Exception e) {
                System.err.println("Ürün kaydedilirken hata: " + e.getMessage());
            }
        }, executorService);
        return urun;
    }

    @Override
    public Optional<Urun> findById(Long id) {
        String sql = "SELECT * FROM urunler WHERE id = ?";
        try {
            Urun urun = jdbcTemplate.queryForObject(sql, this::mapRow, id);
            return Optional.ofNullable(urun);
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            // Ürün bulunamadığında bu hata fırlatılır, ancak hata mesajını yazdırmayacağız
            return Optional.empty();
        } catch (Exception e) {
            System.err.println("Ürün bulunurken beklenmeyen bir hata oluştu: " + e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public List<Urun> findAll() {
        String sql = "SELECT * FROM urunler";
        CompletableFuture<List<Urun>> future = CompletableFuture.supplyAsync(() -> {
            try {
                return jdbcTemplate.query(sql, this::mapRow);
            } catch (Exception e) {
                System.err.println("Ürünler listelenirken hata: " + e.getMessage());
                return Collections.emptyList();
            }
        }, executorService);
        
        try {
            return future.get();
        } catch (Exception e) {
            System.err.println("Ürünler listelenirken hata: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    @Override
    public void delete(Long id) {
        String sql = "DELETE FROM urunler WHERE id = ?";
        CompletableFuture.runAsync(() -> {
            try {
                jdbcTemplate.update(sql, id);
            } catch (Exception e) {
                System.err.println("Ürün silinirken hata: " + e.getMessage());
            }
        }, executorService);
    }

    @Override
    public void update(Urun urun) {
        String sql = "UPDATE urunler SET ad=?, barkod=?, fiyat=?, stokMiktari=?, kategori=?, sonGuncellemeTarihi=?, tedarikci=? WHERE id=?";
        CompletableFuture.runAsync(() -> {
            try {
                jdbcTemplate.update(sql,
                        urun.getAd(),
                        urun.getBarkod(),
                        urun.getFiyat(),
                        urun.getStokMiktari(),
                        urun.getKategori(),
                        urun.getSonGuncellemeTarihi().toInstant(ZoneOffset.UTC).toEpochMilli(),
                        urun.getTedarikci(),
                        urun.getId());
            } catch (Exception e) {
                System.err.println("Ürün güncellenirken hata: " + e.getMessage());
            }
        }, executorService);
    }

    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, java.util.concurrent.TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private Urun mapRow(ResultSet rs, int rowNum) throws SQLException {
        Urun urun = new Urun();
        urun.setId(rs.getLong("id"));
        urun.setAd(rs.getString("ad"));
        urun.setBarkod(rs.getString("barkod"));
        urun.setFiyat(rs.getDouble("fiyat"));
        urun.setStokMiktari(rs.getInt("stokMiktari"));
        urun.setKategori(rs.getString("kategori"));
        long epochMillis = rs.getLong("sonGuncellemeTarihi");
        urun.setSonGuncellemeTarihi(
                Instant.ofEpochMilli(epochMillis).atZone(ZoneOffset.UTC).toLocalDateTime());
        urun.setTedarikci(rs.getString("tedarikci"));
        return urun;
    }
} 