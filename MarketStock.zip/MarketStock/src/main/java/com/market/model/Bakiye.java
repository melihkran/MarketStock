package com.market.model;

public class Bakiye {
    private Long id;
    private double miktar;

    public Bakiye() {
    }

    public Bakiye(Long id, double miktar) {
        this.id = id;
        this.miktar = miktar;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getMiktar() {
        return miktar;
    }

    public void setMiktar(double miktar) {
        this.miktar = miktar;
    }
} 