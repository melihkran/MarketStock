package com.market.model;

public class SatisKaydi {
    private Long id;
    private String urunAdi;
    private Long urunId;
    private double satisFiyati;

    public SatisKaydi() {
    }

    public SatisKaydi(String urunAdi, Long urunId, double satisFiyati) {
        this.urunAdi = urunAdi;
        this.urunId = urunId;
        this.satisFiyati = satisFiyati;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrunAdi() {
        return urunAdi;
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi = urunAdi;
    }

    public Long getUrunId() {
        return urunId;
    }

    public void setUrunId(Long urunId) {
        this.urunId = urunId;
    }

    public double getSatisFiyati() {
        return satisFiyati;
    }

    public void setSatisFiyati(double satisFiyati) {
        this.satisFiyati = satisFiyati;
    }
} 