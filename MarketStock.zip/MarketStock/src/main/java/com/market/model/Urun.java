package com.market.model;

import lombok.Data;
import java.time.LocalDateTime;
import java.time.Instant;
import java.time.ZoneOffset;

@Data
public class Urun {
    private Long id;
    private String ad;
    private String barkod;
    private double fiyat;
    private int stokMiktari;
    private String kategori;
    private LocalDateTime sonGuncellemeTarihi;
    private String tedarikci;

    public Urun() {
        // sonGuncellemeTarihi burada başlatılmıyor, veritabanından gelecek veya
        // eklenirken atanacak
    }

    public Urun(String ad, String barkod, double fiyat, int stokMiktari, String kategori, String tedarikci) {
        this.ad = ad;
        this.barkod = barkod;
        this.fiyat = fiyat;
        this.stokMiktari = stokMiktari;
        this.kategori = kategori;
        this.tedarikci = tedarikci;
        this.sonGuncellemeTarihi = LocalDateTime.now(); // Yeni ürün oluşturulurken ayarlanıyor
    }
}