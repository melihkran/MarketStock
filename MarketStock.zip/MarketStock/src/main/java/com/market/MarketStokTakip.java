package com.market;

import com.market.model.Urun;
import com.market.model.Bakiye;
import com.market.model.SatisKaydi;
import com.market.repository.BakiyeRepository;
import com.market.repository.SatisKaydiRepository;
import com.market.service.UrunService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Optional;

@SpringBootApplication
public class MarketStokTakip implements CommandLineRunner {

    // ANSI Renk Kodları
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_GREEN = "\u001B[32m";

    private final UrunService urunService;
    private final SatisKaydiRepository satisKaydiRepository;
    private final BakiyeRepository bakiyeRepository;
    private final Scanner scanner;

    public MarketStokTakip(UrunService urunService, SatisKaydiRepository satisKaydiRepository, BakiyeRepository bakiyeRepository) {
        this.urunService = urunService;
        this.satisKaydiRepository = satisKaydiRepository;
        this.bakiyeRepository = bakiyeRepository;
        this.scanner = new Scanner(System.in, "UTF-8");
    }

    public static void main(String[] args) {
        SpringApplication.run(MarketStokTakip.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Bakiye ve satış geçmişini yükle
        Optional<Bakiye> savedBakiye = bakiyeRepository.get();
        if (!savedBakiye.isPresent()) {
            bakiyeRepository.save(new Bakiye(1L, 0.0)); // İlk kez ise 0.0 ile başlat
        }

        // Eğer hiç ürün yoksa, örnek ürünleri ekle
        if (urunService.tumUrunleriGetir().isEmpty()) {
            generateDummyProducts();
        }

        // Türkçe karakter hatalarını düzelt
        urunService.fixTurkishCharacterErrors();

        boolean devam = true;

        while (devam) {
            System.out.println("\n************************************");
            System.out.println("=== Market Stok Takip Sistemi ===");
            System.out.println("************************************");
            System.out.println(); // Ana menü başlığı altına boşluk ekle
            System.out.println("- Ürün Ekle (1)");
            System.out.println("- Ürün Listele (2)");
            System.out.println("- Stok Güncelle (3)");
            System.out.println("- Ürün Ara (4)");
            System.out.println("- Ürün Sil (5)");
            System.out.println("- Ürün Sat (7)");
            System.out.println("- Bakiye Sorgula (8)");
            System.out.println("- Satış Geçmişini Sıfırla (9)");
            System.out.println("X Çıkış (6)");
            System.out.print("Seçiminiz: ");

            int secim = -1;
            try {
                secim = scanner.nextInt();
                scanner.nextLine(); // Buffer temizleme
            } catch (InputMismatchException e) {
                System.out.println("Hatalı giriş! Lütfen bir sayı girin.");
                scanner.nextLine(); // Hatalı girdiyi tüket
                continue;
            }

            switch (secim) {
                case 1:
                    urunEkleMenu();
                    break;
                case 2:
                    urunleriListeleMenu();
                    break;
                case 3:
                    stokGuncelleMenu();
                    break;
                case 4:
                    urunAraMenu();
                    break;
                case 5:
                    urunSilMenu();
                    break;
                case 6:
                    devam = false;
                    System.out.println("Program sonlandırılıyor...");
                    urunService.getUrunRepository().shutdown(); // ExecutorService'i kapat
                    satisKaydiRepository.shutdown(); // SatisKaydiRepository ExecutorService'i kapat
                    bakiyeRepository.shutdown(); // BakiyeRepository ExecutorService'i kapat
                    break;
                case 7:
                    urunSatMenu();
                    break;
                case 8:
                    bakiyeSorgulaMenu();
                    break;
                case 9:
                    resetSalesAndBalanceMenu();
                    break;
                default:
                    System.out.println("Geçersiz seçim. Lütfen tekrar deneyin.");
            }
        }

        scanner.close();
    }

    private void urunEkleMenu() {
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== Ürün Ekle ===");
            System.out.println(); // Boşluk ekle
            System.out.println("- Geri Dön (0)");
            System.out.println("Lütfen aşağıdaki bilgileri girin:");

            System.out.print("Ürün Adı: ");
            String ad = scanner.nextLine().trim();
            if (ad.equals("0")) {
                devam = false;
                continue;
            }
            if (ad.isEmpty()) {
                System.out.println("Hata: Ürün adı boş olamaz!");
                continue;
            }

            // DEBUG: Girilen ürün adını kontrol etmek için
            System.out.println("DEBUG: Girilen Ürün Adı: " + ad);

            // Barkodun otomatik oluşturulması
            String barkod = generateRandomBarcode();
            System.out.println("Oluşturulan Barkod: " + barkod);

            double fiyat = 0;
            boolean fiyatGecerli = false;
            while (!fiyatGecerli) {
                System.out.print("Fiyat: ");
                String fiyatStr = scanner.nextLine().trim();
                if (fiyatStr.equals("0")) {
                    devam = false;
                    break;
                }
                try {
                    fiyat = Double.parseDouble(fiyatStr);
                    if (fiyat <= 0) {
                        System.out.println("Hata: Fiyat 0'dan büyük olmalıdır!");
                    } else {
                        fiyatGecerli = true;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Hata: Lütfen geçerli bir sayı girin!");
                }
            }
            if (!devam) continue;

            int stokMiktari = 0;
            boolean stokGecerli = false;
            while (!stokGecerli) {
                System.out.print("Stok Miktarı: ");
                String stokStr = scanner.nextLine().trim();
                if (stokStr.equals("0")) {
                    devam = false;
                    break;
                }
                try {
                    stokMiktari = Integer.parseInt(stokStr);
                    if (stokMiktari < 0) {
                        System.out.println("Hata: Stok miktarı negatif olamaz!");
                    } else {
                        stokGecerli = true;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Hata: Lütfen geçerli bir tam sayı girin!");
                }
            }
            if (!devam) continue;

            System.out.print("Kategori (isteğe bağlı, geri dönmek için 0): ");
            String kategori = scanner.nextLine().trim();
            if (kategori.equals("0")) {
                devam = false;
                continue;
            }

            System.out.print("Tedarikçi (isteğe bağlı, geri dönmek için 0): ");
            String tedarikci = scanner.nextLine().trim();
            if (tedarikci.equals("0")) {
                devam = false;
                continue;
            }

            Urun yeniUrun = new Urun(ad, barkod, fiyat, stokMiktari, kategori, tedarikci);
            urunService.urunEkle(yeniUrun);
            System.out.println(ANSI_GREEN + "Ürün başarıyla eklendi: " + ad + ANSI_RESET);
            devam = false; // Ürün eklendikten sonra menüden çık
            System.out.println("Ana menüye yönlendiriliyor...");
        }
    }

    private void urunleriListeleMenu() {
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== Ürün Listesi ===");
            System.out.println(); // Boşluk ekle
            System.out.println("- Geri Dön (0)");
            List<Urun> urunler = urunService.tumUrunleriGetir();
            if (urunler.isEmpty()) {
                System.out.println("Henüz ürün bulunmamaktadır.");
                System.out.print("Seçiminiz (Geri dönmek için 0): ");
                String input = scanner.nextLine();
                if (input.equals("0")) {
                    devam = false;
                }
                continue;
            }
            System.out.println("Sıralama Kriteri:");
            System.out.println("1. Ada Göre (A-Z)");
            System.out.println("2. Ada Göre (Z-A)");
            System.out.println("3. Fiyata Göre (Artan)");
            System.out.println("4. Fiyata Göre (Azalan)");
            System.out.println("5. Stok Miktarına Göre (Artan)");
            System.out.println("6. Stok Miktarına Göre (Azalan)");
            System.out.print("Seçiminiz (Varsayılan: 1, Geri dönmek için 0): ");

            int siralamaSecim = 1;
            String siralamaInput = scanner.nextLine();
            if (siralamaInput.equals("0")) {
                devam = false;
                continue;
            }
            try {
                if (!siralamaInput.isEmpty()) {
                    siralamaSecim = Integer.parseInt(siralamaInput);
                }
            } catch (NumberFormatException e) {
                System.out.println("Hatalı sıralama seçimi, varsayılan (Ada Göre A-Z) uygulanıyor.");
                siralamaSecim = 1;
            }

            Comparator<Urun> comparator = null;
            switch (siralamaSecim) {
                case 1:
                    comparator = Comparator.comparing(Urun::getAd);
                    break;
                case 2:
                    comparator = Comparator.comparing(Urun::getAd).reversed();
                    break;
                case 3:
                    comparator = Comparator.comparing(Urun::getFiyat);
                    break;
                case 4:
                    comparator = Comparator.comparing(Urun::getFiyat).reversed();
                    break;
                case 5:
                    comparator = Comparator.comparing(Urun::getStokMiktari);
                    break;
                case 6:
                    comparator = Comparator.comparing(Urun::getStokMiktari).reversed();
                    break;
                default:
                    System.out.println("Geçersiz sıralama seçimi, varsayılan (Ada Göre A-Z) uygulanıyor.");
                    comparator = Comparator.comparing(Urun::getAd);
                    break;
            }

            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-5s %-20s %-15s %-10s %-8s %-20s %-20s%n", "ID", "Ad", "Barkod", "Fiyat", "Stok", "Kategori", "Tedarikçi");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
            urunler.stream()
                    .sorted(comparator)
                    .forEach(urun -> {
                        System.out.printf(
                                "%-5d %-20s %-15s %-10.2f %-8d %-20s %-20s%n",
                                urun.getId(), urun.getAd(), urun.getBarkod(), urun.getFiyat(),
                                urun.getStokMiktari(), urun.getKategori(), urun.getTedarikci());
                        System.out.println(); // Ürünler arası boşluk
                    });
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("\nDevam etmek için Enter'a basın...");
            scanner.nextLine(); // Kullanıcının Enter'a basmasını bekle
            devam = false; // Ana menüye dönmek için döngüden çık
            System.out.println("Ana menüye yönlendiriliyor...");
        }
    }

    private void stokGuncelleMenu() {
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== Stok Güncelleme ===");
            System.out.println(); // Boşluk ekle
            System.out.println("- Geri Dön (0)");
            System.out.print("Güncellenecek Ürün ID: ");
            Long urunId = -1L;
            String urunIdStr = scanner.nextLine().trim();
            if (urunIdStr.equals("0")) {
                devam = false;
                continue;
            }
            try {
                urunId = Long.parseLong(urunIdStr);
            } catch (NumberFormatException e) {
                System.out.println("Hatalı giriş! Lütfen geçerli bir Ürün ID'si girin.");
                continue;
            }

            System.out.print("Yeni Stok Miktarı: ");
            int yeniMiktar = -1;
            String yeniMiktarStr = scanner.nextLine().trim();
            if (yeniMiktarStr.equals("0")) {
                devam = false;
                continue;
            }
            try {
                yeniMiktar = Integer.parseInt(yeniMiktarStr);
                if (yeniMiktar < 0) {
                    System.out.println("Hata: Stok miktarı negatif olamaz!");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("Hata: Lütfen geçerli bir tam sayı girin!");
                continue;
            }

            urunService.stokGuncelle(urunId, yeniMiktar);
            System.out.println(ANSI_GREEN + urunId + " ID'li ürünün stok miktarı başarıyla güncellendi." + ANSI_RESET);
            devam = false; // İşlem tamamlandıktan sonra menüden çık
            System.out.println("Ana menüye yönlendiriliyor...");
        }
    }

    private void urunAraMenu() {
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== Ürün Arama ===");
            System.out.println(); // Boşluk ekle
            System.out.println("- Geri Dön (0)");
            System.out.print("Arama Kelimesi (Ad, Barkod veya Kategori, geri dönmek için 0): ");
            String aramaKelimesi = scanner.nextLine().trim();
            if (aramaKelimesi.equals("0")) {
                devam = false;
                continue;
            }

            List<Urun> sonuclar = urunService.urunAra(aramaKelimesi);
            if (sonuclar.isEmpty()) {
                System.out.println("Arama sonucu bulunamadı.");
                System.out.println("\nDevam etmek için Enter'a basın...");
                scanner.nextLine();
                continue;
            }

            System.out.println("Sıralama Kriteri:");
            System.out.println("1. Ada Göre (A-Z)");
            System.out.println("2. Ada Göre (Z-A)");
            System.out.println("3. Fiyata Göre (Artan)");
            System.out.println("4. Fiyata Göre (Azalan)");
            System.out.println("5. Stok Miktarına Göre (Artan)");
            System.out.println("6. Stok Miktarına Göre (Azalan)");
            System.out.print("Seçiminiz (Varsayılan: 1, Geri dönmek için 0): ");

            int siralamaSecim = 1;
            String siralamaInput = scanner.nextLine();
            if (siralamaInput.equals("0")) {
                devam = false;
                continue;
            }
            try {
                if (!siralamaInput.isEmpty()) {
                    siralamaSecim = Integer.parseInt(siralamaInput);
                }
            } catch (NumberFormatException e) {
                System.out.println("Hatalı sıralama seçimi, varsayılan (Ada Göre A-Z) uygulanıyor.");
                siralamaSecim = 1;
            }

            Comparator<Urun> comparator = null;
            switch (siralamaSecim) {
                case 1:
                    comparator = Comparator.comparing(Urun::getAd);
                    break;
                case 2:
                    comparator = Comparator.comparing(Urun::getAd).reversed();
                    break;
                case 3:
                    comparator = Comparator.comparing(Urun::getFiyat);
                    break;
                case 4:
                    comparator = Comparator.comparing(Urun::getFiyat).reversed();
                    break;
                case 5:
                    comparator = Comparator.comparing(Urun::getStokMiktari);
                    break;
                case 6:
                    comparator = Comparator.comparing(Urun::getStokMiktari).reversed();
                    break;
                default:
                    System.out.println("Geçersiz sıralama seçimi, varsayılan (Ada Göre A-Z) uygulanıyor.");
                    comparator = Comparator.comparing(Urun::getAd);
                    break;
            }

            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-5s %-20s %-15s %-10s %-8s %-20s %-20s%n", "ID", "Ad", "Barkod", "Fiyat", "Stok", "Kategori", "Tedarikçi");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
            sonuclar.stream()
                    .sorted(comparator)
                    .forEach(urun -> {
                        System.out.printf(
                                "%-5d %-20s %-15s %-10.2f %-8d %-20s %-20s%n",
                                urun.getId(), urun.getAd(), urun.getBarkod(), urun.getFiyat(),
                                urun.getStokMiktari(), urun.getKategori(), urun.getTedarikci());
                        System.out.println(); // Ürünler arası boşluk
                    });
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("\nDevam etmek için Enter'a basın...");
            scanner.nextLine(); // Kullanıcının Enter'a basmasını bekle
            devam = false; // Ana menüye dönmek için döngüden çık
            System.out.println("Ana menüye yönlendiriliyor...");
        }
    }

    private void urunSilMenu() {
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== Ürün Silme ===");
            System.out.println(); // Boşluk ekle
            System.out.println("- Geri Dön (0)");
            System.out.print("Silinecek Ürün ID: ");
            Long urunId = -1L;
            String urunIdStr = scanner.nextLine().trim();
            if (urunIdStr.equals("0")) {
                devam = false;
                continue;
            }
            try {
                urunId = Long.parseLong(urunIdStr);
            } catch (NumberFormatException e) {
                System.out.println("Hatalı giriş! Lütfen geçerli bir Ürün ID'si girin.");
                continue;
            }

            System.out.print("Bu ürünü silmek istediğinizden emin misiniz? (E/H, geri dönmek için 0): ");
            String onay = scanner.nextLine().trim().toUpperCase();

            if (onay.equals("0")) {
                devam = false;
                continue;
            } else if (onay.equals("E")) {
                urunService.urunSil(urunId);
                System.out.println(ANSI_GREEN + urunId + " ID'li ürün başarıyla silindi." + ANSI_RESET);
                devam = false; // İşlem tamamlandıktan sonra menüden çık
                System.out.println("Ana menüye yönlendiriliyor...");
            } else {
                System.out.println("Ürün silme işlemi iptal edildi.");
                devam = false; // İşlem iptal edildiğinde menüden çık
                System.out.println("Ana menüye yönlendiriliyor...");
            }
        }
    }

    private void urunSatMenu() {
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== Ürün Sat ===\n");
            System.out.println(); // Boşluk ekle
            System.out.println("- Geri Dön (0)");
            System.out.print("Satılacak Ürün ID: ");
            Long urunId = -1L;
            String urunIdStr = scanner.nextLine().trim();
            if (urunIdStr.equals("0")) {
                devam = false;
                continue;
            }
            try {
                urunId = Long.parseLong(urunIdStr);
            } catch (NumberFormatException e) {
                System.out.println("Hatalı giriş! Lütfen geçerli bir Ürün ID'si girin.");
                continue;
            }

            Urun urun = urunService.idIleUrunGetir(urunId);
            if (urun == null) {
                System.out.println("Ürün bulunamadı.");
                System.out.println("\nDevam etmek için Enter'a basın...");
                scanner.nextLine();
                continue;
            }

            System.out.print("Satılacak Adet (Geri dönmek için 0): ");
            int adet = -1;
            String adetStr = scanner.nextLine().trim();
            if (adetStr.equals("0")) {
                devam = false;
                continue;
            }
            try {
                adet = Integer.parseInt(adetStr);
            } catch (InputMismatchException e) {
                System.out.println("Hatalı giriş! Lütfen geçerli bir adet girin.");
                continue;
            }

            if (adet <= 0) {
                System.out.println("Adet 0'dan büyük olmalıdır.");
                System.out.println("\nDevam etmek için Enter'a basın...");
                scanner.nextLine();
                continue;
            }

            if (urun.getStokMiktari() < adet) {
                System.out.printf("Yetersiz stok! Mevcut stok: %d%n", urun.getStokMiktari());
                System.out.println("\nDevam etmek için Enter'a basın...");
                scanner.nextLine();
                continue;
            }

            double odenecekTutar = urun.getFiyat() * adet;
            System.out.printf("Ödenecek Tutar: %.2f TL%n", odenecekTutar);

            System.out.print("Ödemesi yapıldı mı? (E/H, geri dönmek için 0): ");
            String odemeDurumu = scanner.nextLine().trim().toUpperCase();

            if (odemeDurumu.equals("0")) {
                devam = false;
                continue;
            } else if (odemeDurumu.equals("E")) {
                double currentBakiye = bakiyeRepository.get().orElse(new Bakiye(1L, 0.0)).getMiktar();
                currentBakiye += odenecekTutar;
                bakiyeRepository.save(new Bakiye(1L, currentBakiye));
                
                urun.setStokMiktari(urun.getStokMiktari() - adet);
                urunService.urunGuncelle(urun); // Stok bilgisini güncelle

                satisKaydiRepository.save(new SatisKaydi(urun.getAd(), urun.getId(), odenecekTutar));

                System.out.println("\nDevam etmek için Enter'a basın...");
                scanner.nextLine();
                devam = false; // İşlem tamamlandıktan sonra menüden çık
                System.out.println(ANSI_GREEN + "Satış işlemi gerçekleşmiştir. Güncel bakiyeniz: " + String.format("%.2f TL", currentBakiye) + ANSI_RESET);
                System.out.println("Ana menüye yönlendiriliyor...");
            } else {
                System.out.println("Ödeme yapılmadığı için satış işlemi iptal edildi.");
                System.out.println("\nDevam etmek için Enter'a basın...");
                scanner.nextLine();
                devam = false; // İşlem iptal edildiğinde menüden çık
                System.out.println("Ana menüye yönlendiriliyor...");
            }
        }
    }

    private void bakiyeSorgulaMenu() {
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== Bakiye Sorgulama ===\n");
            System.out.println(); // Boşluk ekle
            System.out.println("- Geri Dön (0)");

            // Bakiyeyi veritabanından yükle
            double currentBakiye = bakiyeRepository.get().orElse(new Bakiye(1L, 0.0)).getMiktar();
            System.out.printf("Güncel Bakiye: %.2f TL%n", currentBakiye);
            System.out.println("Satış Geçmişi: ");

            List<SatisKaydi> satisGecmisi = satisKaydiRepository.findAll();

            if (satisGecmisi.isEmpty()) {
                System.out.println("Henüz satış geçmişi bulunmamaktadır.");
            }
            else {
                System.out.println("------------------------------------------------------------------");
                System.out.printf("%-20s %-10s %-15s%n", "Ürün Adı", "Ürün ID", "Satış Fiyatı");
                System.out.println("------------------------------------------------------------------");
                for (SatisKaydi kayit : satisGecmisi) {
                    System.out.printf("%-20s %-10d %-15.2f TL%n", kayit.getUrunAdi(), kayit.getUrunId(), kayit.getSatisFiyati());
                }
                System.out.println("------------------------------------------------------------------");
            }

            System.out.print("Devam etmek için Enter'a basın...");
            scanner.nextLine(); // Kullanıcının Enter'a basmasını bekle
            devam = false; // Ana menüye dönmek için döngüden çık
            System.out.println("Ana menüye yönlendiriliyor...");
        }
    }

    private String generateRandomBarcode() {
        // Bu metod, barkodun otomatik olarak oluşturulması için uygun bir şekilde doldurulmalıdır.
        // Burada basit bir örnek için, 12 haneli bir barkod oluşturuluyor.
        StringBuilder barcode = new StringBuilder();
        for (int i = 0; i < 12; i++) {
            barcode.append((int) (Math.random() * 10));
        }
        return barcode.toString();
    }

    private String convertToEnglishChars(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        text = text.replace('ç', 'c').replace('Ç', 'C');
        text = text.replace('ğ', 'g').replace('Ğ', 'G');
        text = text.replace('ı', 'i').replace('İ', 'I');
        text = text.replace('ö', 'o').replace('Ö', 'O');
        text = text.replace('ş', 's').replace('Ş', 'S');
        text = text.replace('ü', 'u').replace('Ü', 'U');
        return text;
    }

    private void generateDummyProducts() {
        System.out.println("Örnek ürünler ekleniyor...");

        // 15 adet örnek ürün ekle
        urunService.urunEkle(new Urun("Laptop", "123456789012", 12500.00, 10, "Elektronik", "ABC Tedarik"));
        urunService.urunEkle(new Urun("Klavye", "123456789013", 450.00, 50, "Elektronik", "XYZ Tedarik"));
        urunService.urunEkle(new Urun("Mouse", "123456789014", 200.00, 75, "Elektronik", "ABC Tedarik"));
        urunService.urunEkle(new Urun("Monitör", "123456789015", 3000.00, 15, "Elektronik", "PQR Tedarik"));
        urunService.urunEkle(new Urun("Webcam", "123456789016", 350.00, 30, "Elektronik", "XYZ Tedarik"));
        urunService.urunEkle(new Urun("Kulaklık", "123456789017", 600.00, 40, "Elektronik", "ABC Tedarik"));
        urunService.urunEkle(new Urun("Akıllı Telefon", "123456789018", 8000.00, 20, "Elektronik", "XYZ Tedarik"));
        urunService.urunEkle(new Urun("Tablet", "123456789019", 2500.00, 12, "Elektronik", "PQR Tedarik"));
        urunService.urunEkle(new Urun("Kitap", "200000000001", 50.00, 100, "Kitap", "Kitapçı A"));
        urunService.urunEkle(new Urun("Defter", "200000000002", 20.00, 200, "Kırtasiye", "Kırtasiyeci B"));
        urunService.urunEkle(new Urun("Kalem Seti", "200000000003", 75.00, 80, "Kırtasiye", "Kitapçı A"));
        urunService.urunEkle(new Urun("Su Şişesi", "300000000001", 40.00, 150, "Mutfak", "EKO Ürünler"));
        urunService.urunEkle(new Urun("Kahve Makinesi", "300000000002", 1500.00, 5, "Mutfak", "Ev Aletleri"));
        urunService.urunEkle(new Urun("Tişört", "400000000001", 120.00, 60, "Giyim", "Moda Tekstil"));
        urunService.urunEkle(new Urun("Kot Pantolon", "400000000002", 300.00, 35, "Giyim", "Giyim Dünyası"));

        // Yeni eklenen 6 adet ürün
        urunService.urunEkle(new Urun("Şarj Aleti", generateRandomBarcode(), 150.00, 100, "Elektronik", "Tekno Tedarik"));
        urunService.urunEkle(new Urun("Çorap", generateRandomBarcode(), 30.00, 200, "Giyim", "Çorapçı Amca"));
        urunService.urunEkle(new Urun("Ütü Masası", generateRandomBarcode(), 500.00, 10, "Ev Aletleri", "Evim Evim"));
        urunService.urunEkle(new Urun("Örgü İpi", generateRandomBarcode(), 25.00, 150, "Hobi", "Hobici Market"));
        urunService.urunEkle(new Urun("Güç Bankası", generateRandomBarcode(), 400.00, 40, "Elektronik", "Enerji Depo"));
        urunService.urunEkle(new Urun("Dikiş Makinesi", generateRandomBarcode(), 1200.00, 5, "Ev Aletleri", "Ustalar Diyarı"));
        
        System.out.println("Örnek ürünler başarıyla eklendi.");
    }

    private void resetSalesAndBalanceMenu() {
        System.out.println("\n=== Satış Geçmişini Sıfırla ===\n");
        System.out.print("Satış geçmişini sıfırlamak istediğinizden emin misiniz? (E/H): ");
        String onay = scanner.nextLine().trim().toUpperCase();

        if (onay.equals("E")) {
            satisKaydiRepository.deleteAll();
            // bakiyeRepository.resetBakiye(); // Bakiye sıfırlama kaldırıldı
            System.out.println("Satış geçmişi başarıyla sıfırlandı. Bakiye miktarı değişmedi.");
        } else {
            System.out.println("Sıfırlama işlemi iptal edildi.");
        }
        System.out.println("\nDevam etmek için Enter'a basın...");
        scanner.nextLine();
        System.out.println("Ana menüye yönlendiriliyor...");
    }
}