package com.market.service;

import com.market.model.Urun;
import com.market.repository.UrunRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class UrunService {
    private final UrunRepository urunRepository;

    @Autowired
    public UrunService(UrunRepository urunRepository) {
        this.urunRepository = urunRepository;
    }

    public void urunEkle(Urun urun) {
        CompletableFuture.runAsync(() -> {
            try {
                urunRepository.save(urun);
                System.out.println("Ürün başarıyla eklendi: " + urun.getAd());
            } catch (Exception e) {
                System.err.println("Ürün eklenirken hata: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    public List<Urun> tumUrunleriGetir() {
        return urunRepository.findAll();
    }

    public List<Urun> urunAra(String aramaKelimesi) {
        return tumUrunleriGetir().stream()
                .filter(urun -> urun.getAd().toLowerCase().contains(aramaKelimesi.toLowerCase()) ||
                        urun.getBarkod().contains(aramaKelimesi) ||
                        (urun.getKategori() != null
                                && urun.getKategori().toLowerCase().contains(aramaKelimesi.toLowerCase()))
                        ||
                        (urun.getTedarikci() != null
                                && urun.getTedarikci().toLowerCase().contains(aramaKelimesi.toLowerCase())))
                .collect(Collectors.toList());
    }

    public void stokGuncelle(Long urunId, int yeniMiktar) {
        CompletableFuture.runAsync(() -> {
            try {
                Optional<Urun> urunOpt = urunRepository.findById(urunId);
                if (urunOpt.isPresent()) {
                    Urun urun = urunOpt.get();
                    urun.setStokMiktari(yeniMiktar);
                    urunRepository.update(urun);
                    System.out.println(urunId + " ID'li ürünün stok miktarı başarıyla güncellendi.");
                } else {
                    System.err.println(urunId + " ID'li ürün bulunamadı.");
                }
            } catch (Exception e) {
                System.err.println(urunId + " ID'li ürünün stok miktarı güncellenirken hata: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
}