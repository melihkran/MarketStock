package com.market.service;

import com.market.model.Urun;
import com.market.repository.UrunRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class UrunService {
    private final UrunRepository urunRepository;

    @Autowired
    public UrunService(UrunRepository urunRepository) {
        this.urunRepository = urunRepository;
    }

    public void urunEkle(Urun urun) {
        CompletableFuture.runAsync(() -> {
            try {
                urunRepository.save(urun);
                System.out.println("Ürün başarıyla eklendi: " + urun.getAd());
            } catch (Exception e) {
                // System.err.println("Ürün eklenirken hata: " + e.getMessage());
                // e.printStackTrace();
            }
        });
    }

    public List<Urun> tumUrunleriGetir() {
        return urunRepository.findAll();
    }

    public List<Urun> urunAra(String aramaKelimesi) {
        return tumUrunleriGetir().stream()
                .filter(urun -> urun.getAd().toLowerCase().contains(aramaKelimesi.toLowerCase()) ||
                        urun.getBarkod().contains(aramaKelimesi) ||
                        (urun.getKategori() != null
                                && urun.getKategori().toLowerCase().contains(aramaKelimesi.toLowerCase()))
                        ||
                        (urun.getTedarikci() != null
                                && urun.getTedarikci().toLowerCase().contains(aramaKelimesi.toLowerCase())))
                .collect(Collectors.toList());
    }

    public void stokGuncelle(Long urunId, int yeniMiktar) {
        CompletableFuture.runAsync(() -> {
            try {
                Optional<Urun> urunOpt = urunRepository.findById(urunId);
                if (urunOpt.isPresent()) {
                    Urun urun = urunOpt.get();
                    urun.setStokMiktari(yeniMiktar);
                    urunRepository.update(urun);
                    System.out.println(urunId + " ID'li ürünün stok miktarı başarıyla güncellendi.");
                } else {
                    // System.err.println(urunId + " ID'li ürün bulunamadı.");
                }
            } catch (Exception e) {
                // System.err.println(urunId + " ID'li ürünün stok miktarı güncellenirken hata: " + e.getMessage());
                // e.printStackTrace();
            }
        });
    }

    public void urunSil(Long urunId) {
        CompletableFuture.runAsync(() -> {
            try {
                Optional<Urun> urunOpt = urunRepository.findById(urunId);
                if (urunOpt.isPresent()) {
                    urunRepository.delete(urunId);
                    System.out.println(urunId + " ID'li ürün başarıyla silindi.");
                } else {
                    // System.err.println("Silinecek ürün bulunamadı! Lütfen ID'yi tekrar kontrol edin.");
                }
            } catch (Exception e) {
                // System.err.println("Ürün silinirken bir hata oluştu: " + e.getMessage());
                // e.printStackTrace();
            }
        });
    }

    public Urun idIleUrunGetir(Long urunId) {
        Optional<Urun> urunOpt = urunRepository.findById(urunId);
        return urunOpt.orElse(null);
    }

    public void urunGuncelle(Urun urun) {
        CompletableFuture.runAsync(() -> {
            try {
                urunRepository.update(urun);
            } catch (Exception e) {
                // System.err.println("Ürün güncellenirken hata: " + e.getMessage());
                // e.printStackTrace();
            }
        });
    }

    public UrunRepository getUrunRepository() {
        return urunRepository;
    }

    public void fixTurkishCharacterErrors() {
        List<Urun> allUrunler = tumUrunleriGetir();
        for (Urun urun : allUrunler) {
            String originalAd = urun.getAd();
            String correctedAd = originalAd;

            // Örnek düzeltme: "I??kl? Ayakkab?" -> "Işıklı Ayakkabı"
            if (originalAd.contains("I??kl? Ayakkab?")) {
                correctedAd = originalAd.replace("I??kl? Ayakkab?", "Işıklı Ayakkabı");
            }
            if (originalAd.contains("I??kl? Ayakkab?lar")) {
                correctedAd = originalAd.replace("I??kl? Ayakkab?lar", "Işıklı Ayakkabılar");
            }
            // Buraya başka hatalı kelimeler için benzer if blokları eklenebilir

            if (!originalAd.equals(correctedAd)) {
                urun.setAd(correctedAd);
                urunGuncelle(urun); // Güncellenmiş ürünü kaydet
                System.out.println("Ürün adı düzeltildi: " + originalAd + " -> " + correctedAd);
            }
        }
    }
}