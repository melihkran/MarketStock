CREATE TABLE IF NOT EXISTS urunler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ad TEXT NOT NULL,
    barkod TEXT UNIQUE NOT NULL,
    fiyat REAL NOT NULL,
    stokMiktari INTEGER NOT NULL,
    kategori TEXT,
    sonGuncellemeTarihi INTEGER NOT NULL,
    tedarikci TEXT
); 