$Host.UI.RawUI.WindowTitle = "SuperMarketStorage"
java -jar target/market-stok-takip-1.0-SNAPSHOT.jar
Write-Host "`nÇıkmak için bir tuşa basın..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") 